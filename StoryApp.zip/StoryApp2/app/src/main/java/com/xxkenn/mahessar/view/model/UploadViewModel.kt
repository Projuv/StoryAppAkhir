package com.xxkenn.mahessar.view.model

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.xxkenn.mahessar.data.Result
import com.xxkenn.mahessar.data.StoryRepository
import com.xxkenn.mahessar.data.respon.UploadResponse
import okhttp3.MultipartBody
import okhttp3.RequestBody

class UploadViewModel(private val repository: StoryRepository) : ViewModel() {

    suspend fun uploadStory(file: MultipartBody.Part, description: RequestBody): LiveData<Result<UploadResponse>> {
        return repository.uploadImage(file, description)
    }
}