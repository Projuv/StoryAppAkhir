package com.xxkenn.mahessar.data

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.liveData
import androidx.paging.ExperimentalPagingApi
import androidx.paging.Pager
import androidx.paging.PagingConfig
import androidx.paging.PagingData
import androidx.paging.liveData
import com.google.gson.Gson
import com.xxkenn.mahessar.data.api.ApiService
import com.xxkenn.mahessar.data.database.StoryDatabase
import com.xxkenn.mahessar.data.respon.ListStoryItem
import com.xxkenn.mahessar.data.respon.LoginResponse
import com.xxkenn.mahessar.data.respon.RegisterResponse
import com.xxkenn.mahessar.data.respon.UploadResponse
import com.xxkenn.mahessar.data.user.UserModel
import com.xxkenn.mahessar.data.user.UserPreference
import com.xxkenn.mahessar.data.utils.StoryRemoteMediator
import kotlinx.coroutines.flow.Flow
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.HttpException

class StoryRepository private constructor(
    private val database: StoryDatabase,
    private val apiService: ApiService,
    private val userPreference: UserPreference,
) {
    fun getStory(): LiveData<PagingData<ListStoryItem>> {
        @OptIn(ExperimentalPagingApi::class)
        return Pager(config = PagingConfig(
            pageSize = 5
        ),
            remoteMediator = StoryRemoteMediator(database, apiService),
            pagingSourceFactory = {
                database.storyDao().getAllStory()
            }
        ).liveData
    }

    fun getStoriesWithLocation(): LiveData<Result<List<ListStoryItem>>> = liveData {
        emit(Result.Loading)
        try {
            val response = apiService.getStories(location = 1)
            if (response.error == false) {
                emit(Result.Success(response.listStory))
            } else {
                emit(Result.Error(response.message ?: ""))
            }
        } catch (e: Exception) {
            emit(Result.Error(e.message.toString()))
        }
    }

    suspend fun register(
        name: String,
        email: String,
        password: String,
    ): LiveData<Result<RegisterResponse>> = liveData {
        emit(Result.Loading)
        try {
            val response = apiService.register(name, email, password)
            if (!response.error) {
                emit(Result.Success(response))
            } else {
                emit(Result.Error(response.message))
            }
        } catch (e: HttpException) {
            val jsonInString = e.response()?.errorBody()?.string()
            val errorBody = Gson().fromJson(jsonInString, RegisterResponse::class.java)
            emit(Result.Error(errorBody.message.toString()))
        } catch (e: Exception) {
            emit(Result.Error(e.message.toString()))
        }
    }


    suspend fun login(email: String, password: String): LiveData<Result<LoginResponse>> = liveData {
        emit(Result.Loading)
        try {
            val response = apiService.login(email, password)
            emit(Result.Success(response))
        } catch (e: HttpException) {
            val jsonInString = e.response()?.errorBody()?.string()
            val errorBody = Gson().fromJson(jsonInString, LoginResponse::class.java)
            emit(Result.Error(errorBody.message.toString()))
        }
    }

    suspend fun saveSession(user: UserModel) {
        userPreference.saveSession(user)
    }

    fun getSession(): Flow<UserModel> {
        return userPreference.getSession()
    }

    suspend fun logout() {
        userPreference.logout()
    }

    suspend fun uploadImage(
        file: MultipartBody.Part,
        description: RequestBody,
    ): LiveData<Result<UploadResponse>> {
        val resultLiveData = MutableLiveData<Result<UploadResponse>>()
        resultLiveData.postValue(Result.Loading)
        try {
            val response = apiService.uploadImage(file, description)
            if (response.error == false) {
                resultLiveData.postValue(Result.Success(response))
            } else {
                resultLiveData.postValue(Result.Error(response.message.toString()))
            }
        } catch (e: Exception) {
            resultLiveData.postValue(Result.Error(e.message.toString()))
        }
        return resultLiveData
    }


    companion object {
        @Volatile
        private var instance: StoryRepository? = null

        fun clearInstance() {
            instance = null
        }

        fun getInstance(
            database: StoryDatabase,
            apiService: ApiService,
            userPreference: UserPreference,
        ): StoryRepository =
            instance ?: synchronized(this) {
                instance ?: StoryRepository(database, apiService, userPreference)
            }.also { instance = it }
    }
}