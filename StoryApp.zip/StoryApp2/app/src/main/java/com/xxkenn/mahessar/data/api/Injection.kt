package com.xxkenn.mahessar.data.api

import android.content.Context
import com.xxkenn.mahessar.data.StoryRepository
import com.xxkenn.mahessar.data.database.StoryDatabase
import com.xxkenn.mahessar.data.user.UserPreference
import com.xxkenn.mahessar.data.user.dataStore
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking

object Injection {
    fun provideRepository(context: Context): StoryRepository = runBlocking  {
        val pref = UserPreference.getInstance(context.dataStore)
        val user = pref.getSession().first()
        val apiService = ApiConfig.getApiService(user.token)
        val database = StoryDatabase.getDatabase(context)
        StoryRepository.getInstance(database, apiService, pref)
    }

}