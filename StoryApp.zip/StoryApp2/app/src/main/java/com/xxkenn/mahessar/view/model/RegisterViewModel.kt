package com.xxkenn.mahessar.view.model

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.xxkenn.mahessar.data.Result
import com.xxkenn.mahessar.data.StoryRepository
import com.xxkenn.mahessar.data.respon.RegisterResponse

class RegisterViewModel(private var repository: StoryRepository) : ViewModel() {

    suspend fun register(name: String, email: String, password: String) : LiveData<Result<RegisterResponse>> {
        return repository.register(name, email, password)
    }
}