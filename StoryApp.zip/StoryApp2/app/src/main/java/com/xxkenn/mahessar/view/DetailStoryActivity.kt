package com.xxkenn.mahessar.view

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.xxkenn.mahessar.data.respon.ListStoryItem
import com.xxkenn.mahessar.databinding.ActivityDetailStoryBinding

class DetailStoryActivity : AppCompatActivity() {
    private var _binding: ActivityDetailStoryBinding? = null
    private val binding get() = _binding!!

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        _binding = ActivityDetailStoryBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val story = intent.getParcelableExtra<ListStoryItem>(DETAIL_STORY) as ListStoryItem
        setupData(story)
    }

    private fun setupData(storyItem: ListStoryItem) {
        Glide.with(applicationContext).load(storyItem.photoUrl).into(binding.ivAvatar)
        binding.tvName.text = storyItem.name
        binding.tvDesc.text = storyItem.description
    }

    companion object {
        const val DETAIL_STORY = "detail_story"
    }

}