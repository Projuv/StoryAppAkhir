package com.xxkenn.mahessar.view

import androidx.lifecycle.ViewModel
import com.xxkenn.mahessar.data.StoryRepository

class MapsViewModel(
    private val storyRepository: StoryRepository,
) : ViewModel() {
    fun getStories() = storyRepository.getStoriesWithLocation()
}