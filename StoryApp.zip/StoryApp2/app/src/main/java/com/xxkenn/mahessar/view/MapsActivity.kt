package com.xxkenn.mahessar.view

import android.graphics.Bitmap
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.LatLngBounds
import com.google.android.gms.maps.model.MarkerOptions
import com.squareup.picasso.Picasso
import com.squareup.picasso.Target
import com.xxkenn.mahessar.R
import com.xxkenn.mahessar.data.Result
import com.xxkenn.mahessar.data.respon.ListStoryItem
import com.xxkenn.mahessar.databinding.ActivityMapsBinding
import com.xxkenn.mahessar.view.model.ViewModelFactory

class MapsActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var binding: ActivityMapsBinding
    private lateinit var map: GoogleMap
    private lateinit var  progressDialog : AlertDialog

    private val viewModel by viewModels<MapsViewModel> {
        ViewModelFactory.getInstance(this)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        binding = ActivityMapsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.fragment_gmaps) as SupportMapFragment
        mapFragment.getMapAsync(this)
    }

    override fun onMapReady(googleMap: GoogleMap) {
        setMap(googleMap)
        initLocation()
        uiSettings()
        getStories()
    }

    private fun setMap(googleMap: GoogleMap) {
        map = googleMap
    }

    private fun initLocation() {
        val location = LatLng(-6.8957526, 107.6338556)
        val cameraUpdate = CameraUpdateFactory.newLatLngZoom(location, 3f)
        map.animateCamera(cameraUpdate)
    }

    private fun uiSettings() {
        map.uiSettings.apply {
            isZoomControlsEnabled = true
        }
    }

    private fun getStories() {
        viewModel.getStories().observe(this) { result ->
            map.clear()
            when (result) {
                is Result.Success -> {
                    showStoriesOnMap(result.data)
                    dismissLoadingDialog(progressDialog)
                }
                is Result.Error -> {
                    Toast.makeText(this, result.error, Toast.LENGTH_SHORT).show()
                    dismissLoadingDialog(progressDialog)
                }
                is Result.Loading -> progressDialog = showLoadingDialog()
            }
        }
    }

    private fun showStoriesOnMap(stories: List<ListStoryItem>) {
        for (data in stories) {
            if (data.lat != null && data.lon != null) {
                val location = LatLng(data.lat, data.lon)
                val name = data.name ?: ""
                val description = data.description ?: ""
                val url = data.photoUrl ?: ""

                createMapMarker(location, name, description)

            }
        }
    }

    private fun createMapMarker(location: LatLng, name: String, description: String) {
        val boundsBuilder = LatLngBounds.Builder()
        map.addMarker(
            MarkerOptions ()
                . position (location)
                . title(name)
                .snippet (description)

        )
        boundsBuilder.include(location)
        val bounds = boundsBuilder.build()
        val width = resources.displayMetrics.widthPixels
        val height = resources.displayMetrics.heightPixels
        val padding = (width * 0.10).toInt()
        val updateCameraFactory = CameraUpdateFactory.newLatLngBounds(bounds,  width, height, padding)
        map.animateCamera(updateCameraFactory)
    }

    private fun createMapMarkerWithImage(
        location: LatLng,
        name: String,
        description: String,
        url: String,
    ) {
        Picasso.get()
            .load(url)
            .resize(150, 150)
            .into(object : Target {
                override fun onBitmapLoaded(bitmap: Bitmap?, from: Picasso.LoadedFrom?) {
                    map.addMarker(
                        MarkerOptions()
                            .position(location)
                            .title(name)
                            .snippet(description)
                            .icon(bitmap?.let { BitmapDescriptorFactory.fromBitmap(it) })
                    )
                }

                override fun onBitmapFailed(e: Exception?, errorDrawable: Drawable?) {

                }

                override fun onPrepareLoad(placeHolderDrawable: Drawable?) {

                }
            })
    }

    fun showLoadingDialog(): AlertDialog {
        val builder = AlertDialog.Builder(this)
        builder.setView(R.layout.progress_dialog)
        builder.setCancelable(false)
        val dialog = builder.create()
        dialog.show()
        return dialog
    }

    fun dismissLoadingDialog(dialog: AlertDialog) {
        if (dialog.isShowing) {
            dialog.dismiss()
        }
    }
}