package com.xxkenn.mahessar.view.model

import androidx.lifecycle.ViewModel
import com.xxkenn.mahessar.data.StoryRepository
import com.xxkenn.mahessar.data.user.UserModel

class LoginViewModel(private var repository: StoryRepository) : ViewModel() {

    suspend fun login(email: String, password: String) = repository.login(email, password)
    suspend fun saveSession(user: UserModel) {
        repository.saveSession(user)
    }

}